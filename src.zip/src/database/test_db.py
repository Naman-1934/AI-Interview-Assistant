from db import create_table

create_table()

print("Database Created Successfully")