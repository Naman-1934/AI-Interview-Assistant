import sqlite3

def create_connection():
    conn = sqlite3.connect("Interview.db")

    return conn

def create_table():
    conn = create_connection()

    cursor = conn.cursor()

    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS interview_results(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT,
            expected_answer TEXT,
            candidate_answer TEXT,
            technical_score TEXT,
            correctness_score TEXT,
            communication_score TEXT,
            overall_score TEXT,
            feedback TEXT
        )
        """
    )

    conn.commit()
    conn.close()

def save_result(question, expected_answer, candidate_answer, evaluation):
    conn = create_connection()

    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO interview_results(
        question,
        expected_answer,
        candidate_answer,
        technical_score,
        correctness_score,
        communication_score,
        overall_score,
        feedback
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            question,
            expected_answer,
            candidate_answer,
            evaluation["technical_score"],
            evaluation["correctness_score"],
            evaluation["communication_score"],
            evaluation["overall_score"],
            evaluation["feedback"]
        )
    )

    conn.commit()
    conn.close()